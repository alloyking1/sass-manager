
@props(['name','value'])
<textarea id="myeditorinstance" name={{ $name }}>
  {!! $value !!}
</textarea>